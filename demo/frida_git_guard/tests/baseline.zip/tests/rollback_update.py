"""Restore the previous source version from baseline.zip; no system configuration changes."""
import argparse
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ['backend.py', 'guard.py', 'watch_agent.js', 'README.md', '.gitignore',
         'requirements.txt', 'agent.js', 'verify.py', 'rollback.py']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, required=True)
    target = parser.parse_args().target.resolve(strict=True)
    if target != ROOT and not target.is_relative_to(ROOT):
        raise ValueError('Target must remain inside this demo directory')
    with zipfile.ZipFile(Path(__file__).with_name('baseline.zip')) as source:
        assert source.testzip() is None
        for name in FILES:
            (target / name).write_bytes(source.read(name))
    config = target / 'config.json'
    if config.exists():
        config.unlink()
    print('Previous source restored; no Git or system configuration changed.')


if __name__ == '__main__':
    main()
